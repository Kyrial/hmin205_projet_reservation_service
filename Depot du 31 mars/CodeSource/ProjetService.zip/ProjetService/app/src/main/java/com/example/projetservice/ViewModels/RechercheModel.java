package com.example.projetservice.ViewModels;

import android.app.Activity;
import android.database.Cursor;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.room.ColumnInfo;

import com.example.projetservice.database.AppDataBase;
import com.example.projetservice.database.Repository;
import com.example.projetservice.database.ServiceEntity;

public class RechercheModel extends ViewModel {
    private MutableLiveData<Cursor> cursorService =  new MutableLiveData<Cursor>();;
    private Activity context = null;
    private Repository referenciel=null;

    public void setContext(Activity Context){
        context = Context;
    }

    public void initDatabase(){
        if(context != null) {
            referenciel = new Repository(context);
            //referenciel.deletesAllService();
            test();
            updateCursor();
        }
    }

    public void updateCursor(){

        if(referenciel!= null)

            AppDataBase.databaseWriteExecutor.execute(() -> {

                Cursor Cursor = referenciel.getCursorService();
                Log.v("1_recherchemodel", "avant");
                if (Cursor !=null) {
                    cursorService.postValue(Cursor);
                    Log.v("1_recherchemodel", "preès");
                }
            });
    }

    public void updateCursor(String str){

        if(referenciel!= null)

            AppDataBase.databaseWriteExecutor.execute(() -> {

                Cursor Cursor = referenciel.getCursorService(str);
                Log.v("1_recherchemodel", "avant");
                if (Cursor !=null) {
                    cursorService.postValue(Cursor);
                    Log.v("1_recherchemodel", "preès");
                }
            });
    }

    public MutableLiveData<Cursor> getCursorService() {
       /* if (cursorService == null){
            cursorService = new MutableLiveData<Cursor>();
            cursorService.setValue();}*/
        return cursorService;

    }


    public void test() {
        for(int i =1; i<30; i++) {

            ServiceEntity se = new ServiceEntity();
            se._id = i;
            se.nom = "Service Exemple "+ i;
            se.description = "Test ";
            if (referenciel != null)
                referenciel.insertUser(se);
        }
    }


}
