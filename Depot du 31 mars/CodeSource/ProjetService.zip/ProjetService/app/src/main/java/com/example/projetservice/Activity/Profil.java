package com.example.projetservice.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.projetservice.R;
import com.example.projetservice.database.UtilisateurEntity;
import com.google.android.material.button.MaterialButton;

public class Profil extends AppCompatActivity {

    private UtilisateurEntity user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);


        MaterialButton retour = findViewById(R.id.retourAnnuler);
        retour.setOnClickListener(v -> {
            finish();
        });

        initAndVerifData();

    }


    public void initAndVerifData(){
        Intent intent = getIntent();
        UtilisateurEntity User = (UtilisateurEntity)intent.getSerializableExtra("USER");
        if (User != null) {
            user = User;

            //remplir champs
            Log.i("1_recherche", "user Recuperer profil");
        }
        else
        {
            Log.i("1_recherche", "aucune donne récupéré");
            Toast.makeText(this, R.string.erreur_donnees_user, Toast.LENGTH_LONG).show();
            finish();

        }

        MaterialButton retour = findViewById(R.id.retourAnnuler);
        retour.setOnClickListener(v -> {
            finish();
        });
    }










}