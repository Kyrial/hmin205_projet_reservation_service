package com.example.projetservice.database;


import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.room.Query;

import java.util.ArrayList;

//Gère les requete envoyer a la BDD
public class Repository {
    private DAO dao;


    public Repository(Context context) {
        AppDataBase db = AppDataBase.getDatabase(context);
        dao = db.dao();
        Log.v("1_repesitory", "bdd chargé");
    }

    public void insertUser(UtilisateurEntity user) {
        AppDataBase.databaseWriteExecutor.execute(() -> {
            dao.insert(user);
        });
    }

    public void insertUser(ServiceEntity service) {
        AppDataBase.databaseWriteExecutor.execute(() -> {
            dao.insert(service);
        });
    }



    public UtilisateurEntity connexion(String identifiant, String motdepasse){
        return dao.seConnecter(identifiant, motdepasse);
    }

    public UtilisateurEntity getUser(String identifiant){
        return dao.getUser(identifiant);
    }



    public UtilisateurEntity inscription(String identifiant, String motdepasse, String mail, String type){
        UtilisateurEntity user = dao.getUser(identifiant);
        if( user != null)
            return null;
        else {
            UtilisateurEntity newUser = new UtilisateurEntity();
            newUser.pseudo = identifiant;
            newUser.mdp = motdepasse;
            newUser.email = mail;
            newUser.type = type;

            newUser.id= dao.getDataCountUser()+1;
            dao.insert(newUser);
            return newUser;
        }
    }






    public void deletesAllService() {
        AppDataBase.databaseWriteExecutor.execute(() -> {
            dao.deleteAllservice();
        });
    }


    public Cursor getCursorService(){
        return dao.getServiceCursor();
    }
    public Cursor getCursorService(String str){
        if(str != "" || str != null) {
            str = "%"+str+"%";
            return dao.getServiceCursor(str);
        }
        return dao.getServiceCursor();

    }
}
